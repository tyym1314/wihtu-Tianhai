import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import Ajv from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import {migrateWallet,provisionWallet,createWalletServer} from './server/wallet/index.mjs';
import {startPartnerWallet} from './examples/partner-wallet/server.mjs';
import {createPartnerHost,loadConfig} from './specs/examples/partner-host/server.mjs';
import {signedHeaders,OasisClient} from './specs/examples/sdk-node.mjs';
import {OasisHost} from './public/sdk/oasis-h5.mjs';
const read=name=>readFile(new URL(name,import.meta.url),'utf8');
const manifest=JSON.parse(await read('MANIFEST.json'));
for(const entry of manifest.files){const content=await readFile(new URL(entry.path,import.meta.url));assert.equal(content.length,entry.bytes,entry.path);assert.equal(createHash('sha256').update(content).digest('hex'),entry.sha256,entry.path);}
for(const fn of [migrateWallet,provisionWallet,createWalletServer,startPartnerWallet,createPartnerHost,loadConfig,signedHeaders,OasisClient,OasisHost])assert.equal(typeof fn,'function');
const spec=JSON.parse(await read('specs/openapi.json'));assert.equal(spec.openapi,'3.1.0');
const vector=JSON.parse(await read('specs/examples/signature-vector.json'));
const signed=signedHeaders({keyId:vector.key_id,secretBase64:vector.test_secret_base64,direction:vector.direction,method:vector.method,path:vector.canonical_target,rawBody:vector.raw_body_utf8,requestId:vector.request_id,timestamp:vector.timestamp,nonce:vector.nonce});
assert.equal(signed['X-GP-Signature'],vector.signature_header);
const ajv=new Ajv({strict:false});addFormats(ajv);const schema=spec.paths[vector.canonical_target].post.requestBody.content['application/json'].schema;const validate=ajv.compile({...schema,components:spec.components});assert.ok(validate(JSON.parse(vector.raw_body_utf8)),ajv.errorsText(validate.errors));
for(const path of ['config/partner-host.example.json','examples/partner-wallet/config.example.json']){const c=JSON.parse(await read(path));assert.ok(c.secret_base64.startsWith('REPLACE'));assert.ok(c.key_id.startsWith('REPLACE'));assert.ok(c.scope.app_id.startsWith('REPLACE'));}
const profiles=JSON.parse(await read('specs/math-profiles.json'));assert.equal(profiles.profiles.length,4);for(const p of profiles.profiles)assert.match(p.math_config_hash,/^[a-f0-9]{64}$/);
console.log(JSON.stringify({verified_files:manifest.files.length,module_imports:9,public_hmac_vector:true,openapi_reservation_validation:true,placeholder_configs:true,math_profiles:4,network_requests:0,listening_ports:0,database_changes:0}));
