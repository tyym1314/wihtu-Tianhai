# OASIS 合作方沙箱接入包 · v0.6

这是可独立解压、安装和运行的合作方示例；不需要平台源代码。包括独立 PostgreSQL 参考钱包、Node BFF、移动 H5 宿主、Node/H5 SDK、公开协议和数学版本元数据。平台 API 与十三款游戏仍由平台部署方提供，本包不包含游戏源码或素材，也不包含平台账号、可用密钥、token 或任何运行账务。

## 1. 安装与离线结构验证

要求 Node.js 22+、npm，以及你单独准备的 PostgreSQL 数据库。在**本文件所在包根目录**执行：

```sh
npm ci
npm run verify
```

verify 校验文件摘要、模块导入、相对路径、OpenAPI、占位配置和公开 HMAC 测试向量。它不监听端口、不访问平台或数据库、不创建资金操作。package-lock 从平台依赖锁的四个必要依赖闭包生成；不附带 node_modules。构建清单见 MANIFEST.json。

## 2. 取得专用沙箱 App

先向平台部署方取得平台公共 URL 和独立合作方账号。在平台教程中创建专用 App、保存一次性显示的 partner-to-platform key/secret，**立即暂停新 App**，随后配置独立钱包；不要提前试玩或运行检查。完整顺序见 [Phase F 接入教程](specs/phase-f-self-integration.md)。平台服务启动、钱包出站 origin 允许列表属于部署方职责，不在这个示例包中启动平台。

## 3. 独立参考钱包

由你的数据库管理员创建专用沙箱库，名字与平台当前数据库不同。不要删除、覆盖或复用任何现有平台库。把连接参数替换为自己的本机 PostgreSQL；以下命令不会自动建库：

```sh
mkdir -p .local/partner-wallet
chmod 700 .local .local/partner-wallet
cp examples/partner-wallet/config.example.json .local/partner-wallet/config.json
chmod 600 .local/partner-wallet/config.json
```

在私有 config.json 填平台接入台复制的完整 scope、**独立的 platform-to-wallet** key/secret、测试用户。两个方向密钥不能复用。所有 REPLACE 值必须替换；数学版本只复制 [math-profiles.json](specs/math-profiles.json) 内每项的 game_id、math_version、math_config_hash、max_payout_multiplier，先请平台确认当前启用版本。四条对应 Thunder/Tiger 的 98/99 沙箱目标档位，不是生产认证。本包没有派彩计算源码。

```sh
OASIS_PARTNER_WALLET_DATABASE_URL='postgres://REPLACE_DB_USER:REPLACE_DB_PASSWORD@127.0.0.1:5432/REPLACE_PARTNER_SANDBOX_DB' \
OASIS_PARTNER_WALLET_CONFIG="$PWD/.local/partner-wallet/config.json" \
npm run wallet
```

钱包仅监听 127.0.0.1:8801。首次启动会在专用库建表并创建配置中的测试余额，重启不重置账务。请平台部署方将这个精确钱包 origin 加入允许列表，然后在暂停的新 App 里绑定钱包方向密钥并查询余额，确认后启用 App。查询会登记 nonce，钱包也可能释放已到期冻结；它不是发币接口。钱包配置、数据库和密钥自行私有保存，不放入 public/specs。

## 4. 独立 BFF 与 H5

把宿主 http://127.0.0.1:8800 登记到这个 App 的 allowed_origins。配置使用创建 App 时保存的 **partner-to-platform** 凭证：

```sh
cp config/partner-host.example.json .local/partner-host.json
chmod 600 .local/partner-host.json
# 私下编辑配置，替换平台地址、scope、key_id、secret_base64。
npm run host -- --config "$PWD/.local/partner-host.json"
```

访问 http://127.0.0.1:8800；菜单来自平台签名 API，游戏 iframe 由平台提供。不要用文件双击方式打开 index.html。配置必须是非符号链接的 0600 普通文件，固定用户 demo_player 必须已在当前 App 钱包开户。见 [BFF/H5 说明](specs/examples/partner-host/README.md)。这个单用户本机示例不是生产登录服务，不能原样公开；真实 App 必须用自己的后端登录身份映射用户。

## 5. 后续验收与边界

按平台教程运行八项真实检查，会使用两个专用测试用户各 100 测试币完成三消结算。不要在有正常用户资产或未决局的 App 运行。消息握手只传展示状态，余额与派彩以服务端原操作及钱包凭据为准。HMAC 向量的固定 test_secret 是公开测试值，绝不能用作运行凭证。

本包验证不等于真实合作方接入完成；原生 WebView、公网 TLS、实际送礼币账、生产身份与密钥托管、并发容量、容灾及发布仍需分别验收。OpenAPI 保留历史设计候选说明和 .invalid 占位 server；实际本地接口与限制以 Phase F 教程为准。
